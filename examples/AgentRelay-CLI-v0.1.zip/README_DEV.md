# AgentRelay CLI v0.1（最小可运行骨架）

## 本地运行
```bash
pnpm i
pnpm dev -- init demo-001
pnpm dev -- status demo-001
pnpm dev -- next demo-001
```

## 构建并使用 bin
```bash
pnpm build
node dist/index.js status demo-001
```
