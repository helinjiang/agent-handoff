#!/usr/bin/env node
import { Command } from "commander";
import { cmdInit } from "./commands/init.js";
import { cmdStatus } from "./commands/status.js";
import { cmdNext } from "./commands/next.js";

const program = new Command();

program
  .name("agent-relay")
  .description("AgentRelay CLI (v0.1) - step-pipeline relay orchestrator")
  .version("0.1.0");

program.addCommand(cmdInit());
program.addCommand(cmdStatus());
program.addCommand(cmdNext());

program.parse(process.argv);
