import path from "node:path";
import { promises as fs } from "node:fs";
import { loadYaml } from "./yaml.js";
import { isNonEmptyFile, readTextIfExists } from "./fs.js";
import type { Workspace, Workflow, State } from "./types.js";

export async function loadWorkspace(root: string): Promise<Workspace> {
  const workflowPath = path.join(root, "workflow.yaml");
  const statePath = path.join(root, "state.json");

  const workflowText = await fs.readFile(workflowPath, "utf-8");
  const workflow = loadYaml<Workflow>(workflowText);

  const stateText = await readTextIfExists(statePath);
  if (!stateText) {
    throw new Error(`缺少 state.json：${statePath}`);
  }
  const state = JSON.parse(stateText) as State;

  const stepOutputs = await Promise.all(
    workflow.steps.map(async (s) => {
      const outPath = path.join(root, s.output);
      const ok = await isNonEmptyFile(outPath);
      return { path: s.output, isNonEmpty: ok };
    })
  );

  return { root, workflow, state, stepOutputs };
}
