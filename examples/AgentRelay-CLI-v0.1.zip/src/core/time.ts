export function nowIso(): string {
  // keep ISO with timezone (toISOString is UTC, acceptable for logs/state)
  return new Date().toISOString();
}
