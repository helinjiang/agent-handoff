import YAML from "yaml";

export function loadYaml<T>(text: string): T {
  return YAML.parse(text) as T;
}

export function dumpYaml(obj: unknown): string {
  return YAML.stringify(obj);
}
