type PromptVars = {
  workspace: string;
  stepIndex: number;
  stepId: string;
  executor: string;
  inputPaths: string[];
  outputPath: string;
  acceptance: string[];
};

export function renderStepPrompt(template: string, vars: PromptVars): string {
  return template
    .replaceAll("{{workspace}}", vars.workspace)
    .replaceAll("{{stepIndex}}", String(vars.stepIndex))
    .replaceAll("{{stepId}}", vars.stepId)
    .replaceAll("{{executor}}", vars.executor)
    .replaceAll("{{inputPaths}}", vars.inputPaths.join("\n"))
    .replaceAll("{{outputPath}}", vars.outputPath)
    .replaceAll("{{acceptance}}", vars.acceptance.join("\n"));
}
