export type Workflow = {
  name: string;
  steps: Step[];
};

export type Step = {
  id: string;
  executor?: string; // trae/shell/api/manual
  input: string;
  output: string;
  acceptance?: string[];
};

export type State = {
  currentIndex: number; // 0-based
  status: "running" | "blocked" | "done";
  updatedAt: string;
  reason?: string;
};

export type Workspace = {
  root: string;
  workflow: Workflow;
  state: State;
  stepOutputs: { path: string; isNonEmpty: boolean }[];
};
