import type { Workspace } from "./types.js";

/**
 * v0.1 最简规则：找到第一个 output 不存在或为空的 step
 * 返回其 index（0-based）。若全部完成，返回 null。
 */
export async function detectNextStepIndex(ws: Workspace): Promise<number | null> {
  const total = ws.workflow.steps.length;
  for (let i = 0; i < total; i++) {
    if (!ws.stepOutputs[i]?.isNonEmpty) return i;
  }
  return null;
}
