import { Command } from "commander";
import path from "node:path";
import { loadWorkspace } from "../core/workspace.js";
import { detectNextStepIndex } from "../core/state-machine.js";

export function cmdStatus(): Command {
  return new Command("status")
    .argument("<workspace>", "workspace path")
    .description("Show current step status (completed/missing outputs)")
    .action(async (workspace: string) => {
      const wsPath = path.resolve(process.cwd(), workspace);
      const ws = await loadWorkspace(wsPath);

      const nextIdx = await detectNextStepIndex(ws);
      const total = ws.workflow.steps.length;

      console.log(`Workspace: ${wsPath}`);
      console.log(`Status: ${ws.state.status}`);
      console.log(`CurrentIndex(state): ${ws.state.currentIndex} (0-based)`);
      console.log(`NextStep(detected): ${nextIdx === null ? "DONE" : `${nextIdx + 1}/${total} - ${ws.workflow.steps[nextIdx].id}`}`);
      console.log("");

      for (let i = 0; i < total; i++) {
        const step = ws.workflow.steps[i];
        const done = ws.stepOutputs[i]?.isNonEmpty ? "✅" : "⏳";
        console.log(`${done} ${String(i + 1).padStart(2, "0")} ${step.id}`);
        console.log(`   input : ${step.input}`);
        console.log(`   output: ${step.output}`);
      }
    });
}
