import { Command } from "commander";
import path from "node:path";
import { loadWorkspace } from "../core/workspace.js";
import { detectNextStepIndex } from "../core/state-machine.js";
import { renderStepPrompt } from "../core/prompt.js";
import { readTextIfExists } from "../core/fs.js";

export function cmdNext(): Command {
  return new Command("next")
    .argument("<workspace>", "workspace path")
    .option("--template <path>", "prompt template path (default: prompts/STEP_GENERIC.md)", "prompts/STEP_GENERIC.md")
    .description("Print next step instruction and generated prompt (TRAE assisted mode)")
    .action(async (workspace: string, opts: { template: string }) => {
      const wsPath = path.resolve(process.cwd(), workspace);
      const ws = await loadWorkspace(wsPath);

      const nextIdx = await detectNextStepIndex(ws);
      if (nextIdx === null) {
        console.log("✅ 已完成：所有 step 的 output 都已存在且非空。");
        return;
      }

      const step = ws.workflow.steps[nextIdx];
      const templatePath = path.resolve(process.cwd(), opts.template);
      const template = await readTextIfExists(templatePath);
      if (!template) {
        console.error(`next: 找不到模板文件: ${templatePath}`);
        process.exitCode = 1;
        return;
      }

      const prompt = renderStepPrompt(template, {
        workspace: path.basename(wsPath),
        stepIndex: nextIdx + 1,
        stepId: step.id,
        executor: step.executor ?? "trae",
        inputPaths: [`- ${step.input}`],
        outputPath: step.output,
        acceptance: step.acceptance?.length ? step.acceptance.map(a => `- ${a}`) : ["- 按上一步交接执行，输出结构化结果并可落盘"],
      });

      // Instruction header
      console.log(`下一步：Step ${String(nextIdx + 1).padStart(2, "0")} - ${step.id}`);
      console.log(`Executor：${step.executor ?? "trae"}`);
      console.log(`输入：${step.input}`);
      console.log(`输出：${step.output}`);
      console.log("");
      console.log("建议 TRAE Task 标题：");
      console.log(`${String(nextIdx + 1).padStart(2, "0")} - ${step.id} - <一句话目标>`);
      console.log("");
      console.log("==== 复制以下 Prompt 到 TRAE（assisted mode）====");
      console.log(prompt);
    });
}
