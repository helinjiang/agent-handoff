import { Command } from "commander";
import path from "node:path";
import { promises as fs } from "node:fs";
import { dumpYaml } from "../core/yaml.js";
import { ensureDir, writeFileIfNotExists } from "../core/fs.js";
import { nowIso } from "../core/time.js";

type InitOptions = {
  steps?: string;
};

export function cmdInit(): Command {
  const cmd = new Command("init")
    .argument("<workspace>", "workspace directory name or path")
    .option("--steps <list>", "comma-separated step ids (default: analyze,implement,verify)", "analyze,implement,verify")
    .description("Initialize a workspace template (workflow.yaml + steps/* + state.json + events.jsonl)")
    .action(async (workspace: string, options: InitOptions) => {
      const stepIds = (options.steps ?? "analyze,implement,verify")
        .split(",")
        .map(s => s.trim())
        .filter(Boolean);

      if (stepIds.length < 2) {
        console.error("init: --steps 至少需要 2 个 step id，例如 analyze,implement");
        process.exitCode = 1;
        return;
      }

      const wsPath = path.resolve(process.cwd(), workspace);
      await ensureDir(wsPath);

      // brief
      await writeFileIfNotExists(path.join(wsPath, "brief.md"), `# brief\n\n目标：\n\n约束：\n\n`);

      // workflow.yaml
      const steps = stepIds.map((id, idx) => {
        const nn = String(idx + 1).padStart(2, "0");
        const input = idx === 0 ? "brief.md" : `steps/${String(idx).padStart(2, "0")}-${stepIds[idx - 1]}/output.md`;
        const output = `steps/${nn}-${id}/output.md`;
        return {
          id,
          executor: "trae",
          input,
          output,
        };
      });

      const workflow = { name: path.basename(wsPath), steps };
      const workflowYaml = dumpYaml(workflow);
      await fs.writeFile(path.join(wsPath, "workflow.yaml"), workflowYaml, "utf-8");

      // steps folders
      for (let i = 0; i < stepIds.length; i++) {
        const nn = String(i + 1).padStart(2, "0");
        const id = stepIds[i];
        const stepDir = path.join(wsPath, "steps", `${nn}-${id}`);
        await ensureDir(stepDir);

        await writeFileIfNotExists(path.join(stepDir, "input.md"), "# input\n\n（由上一步 output 或 brief 摘要生成）\n");
        await writeFileIfNotExists(path.join(stepDir, "output.md"), "# output\n\n（本步骤输出落盘于此）\n");
        await writeFileIfNotExists(path.join(stepDir, "meta.json"), JSON.stringify({
          summary: "",
          decisions: [],
          risks: [],
          next: ""
        }, null, 2) + "\n");
      }

      // state.json
      const state = {
        currentIndex: 0,
        status: "running",
        updatedAt: nowIso(),
      };
      await fs.writeFile(path.join(wsPath, "state.json"), JSON.stringify(state, null, 2) + "\n", "utf-8");

      // events.jsonl
      await writeFileIfNotExists(path.join(wsPath, "events.jsonl"), "");

      console.log(`✅ 已初始化 workspace: ${wsPath}`);
      console.log(`- steps: ${stepIds.join(", ")}`);
    });

  return cmd;
}
